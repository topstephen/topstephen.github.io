package com.tqgoblin.utils;

import freemarker.template.Configuration;
import freemarker.template.Template;

import java.io.File;
import java.io.FileWriter;

public class FreemarkerUtil {
    public static void generateCode(com.tqgoblin.model.Configuration cfg) throws Exception {
        Configuration configuration = new Configuration(Configuration.getVersion());
        String path = FreemarkerUtil.class.getClassLoader().getResource("templates").getPath();
        configuration.setDirectoryForTemplateLoading(new File(path));
        String packagePath = cfg.getPackageName().replace(".", "/")+"/";
        File file = new File(cfg.getPath() + packagePath);
        if (!file.exists()){
            file.mkdirs();
        }

        Template modelTemplate = configuration.getTemplate("model.ftl");
        modelTemplate.process(cfg,new FileWriter(new File(cfg.getPath()+packagePath+cfg.getTable()+"Model.java")));

        Template daoTemplate = configuration.getTemplate("dao.ftl");
        daoTemplate.process(cfg,new FileWriter(new File(cfg.getPath()+packagePath+cfg.getTable()+"Dao.java")));

        Template serviceTemplate = configuration.getTemplate("service.ftl");
        serviceTemplate.process(cfg,new FileWriter(new File(cfg.getPath()+packagePath+cfg.getTable()+"Service.java")));

        Template controllerTemplate = configuration.getTemplate("controller.ftl");
        controllerTemplate.process(cfg,new FileWriter(new File(cfg.getPath()+packagePath+cfg.getTable()+"Controller.java")));

    }
}

package com.tqgoblin.utils;

import com.tqgoblin.model.ColumnModel;
import com.tqgoblin.model.Configuration;
import com.tqgoblin.model.TableModel;

import java.sql.*;
import java.util.*;

public class MysqlUtil {
    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //获取连接
    public static Connection getConnection(Configuration configuration) throws SQLException {
        String url = "jdbc:mysql://"+configuration.getAddress()+":"+configuration.getPort();
        Connection connection = null;
        connection = DriverManager.getConnection(url, configuration.getUserName(), configuration.getPassword());
        connection.setAutoCommit(true);
        return connection;
    }

    //释放资源
    public static void release(Connection connection, Statement statement, ResultSet resultSet) throws SQLException {
        if (connection!=null){
            connection.close();
        }
        if (statement!=null){
            statement.close();
        }
        if (resultSet!=null){
            resultSet.close();
        }
    }

    //执行sql   在控制台中显示所有的数据库名称
    public static void executeSqlForShowDatabases(Connection connection,Configuration configuration) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("show databases;");
        Set<String> databases = new HashSet<String>();
        while (resultSet.next()){
            String databaseName = resultSet.getString(1);
            databases.add(databaseName);
            System.out.println(databaseName);
        }
        configuration.setDatabases(databases);
        MysqlUtil.release(null,statement,resultSet);
    }

    //执行sql    显示所有的表名称
    public static void executeSqlForShowTables(Connection connection,Configuration configuration) throws SQLException {
        Statement statement = connection.createStatement();
        statement.execute("use "+configuration.getDatabase());
        ResultSet resultSet = statement.executeQuery("show tables");
        Set<String> tables = new HashSet<String>();
        while (resultSet.next()){
            String tableName = resultSet.getString(1);
            tables.add(tableName);
            System.out.println(tableName);
        }
        MysqlUtil.release(null,statement,resultSet);
    }

    //执行sql   查看表结构  能拿到表的字段 以及字段的数据类型
    public static void executeSqlForDescTable(Connection connection,Configuration configuration) throws SQLException {
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery("desc "+configuration.getTable());
        Set<ColumnModel> columnModels = new HashSet<ColumnModel>();//当前这个表中所有的字段及类型
        while (resultSet.next()){
            String columnName = resultSet.getString(1);
            String columnType = resultSet.getString(2);
            ColumnModel columnModel = new ColumnModel();
            columnModel.setColumnName(columnName);
            if (columnType.contains("varchar")||columnType.contains("char")){
                columnModel.setType("String");
            }else if (columnType.contains("int")){
                columnModel.setType("Integer");
            }else if (columnType.contains("datetime")){
                columnModel.setType("Date");
            }else if (columnType.contains("bigint")){
                columnModel.setType("Long");
            }
            columnModels.add(columnModel);
//            System.out.println(columnName+"=====>"+columnType);
        }
        TableModel tableModel = new TableModel();
        tableModel.setTableName(configuration.getTable());
        tableModel.setColumnModels(columnModels);
        configuration.setTableModel(tableModel);
        MysqlUtil.release(null,statement,resultSet);

    }
}

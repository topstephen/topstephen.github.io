package com.tqgoblin.model;

import java.util.Set;

public class TableModel {
    private String tableName;
    private Set<ColumnModel> columnModels;


    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Set<ColumnModel> getColumnModels() {
        return columnModels;
    }

    public void setColumnModels(Set<ColumnModel> columnModels) {
        this.columnModels = columnModels;
    }
}

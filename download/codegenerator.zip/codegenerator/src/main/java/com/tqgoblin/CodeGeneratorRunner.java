package com.tqgoblin;

import com.tqgoblin.model.Configuration;
import com.tqgoblin.utils.FreemarkerUtil;
import com.tqgoblin.utils.MysqlUtil;

import java.sql.Connection;
import java.util.Scanner;

public class CodeGeneratorRunner {
    public static void main(String[] args) throws Exception {
        Configuration configuration = new Configuration();
        Scanner scan = new Scanner(System.in);
        System.out.println("请输入Mysql服务器ip地址");
        if (scan.hasNextLine()){
            String address = scan.nextLine();
            configuration.setAddress(address);
        }
        System.out.println("请输入Mysql服务器端口");
        if (scan.hasNextLine()){
            String port = scan.nextLine();
            configuration.setPort(port);
        }
        System.out.println("请输入Mysql服务器用户名");
        if (scan.hasNextLine()){
            String userName = scan.nextLine();
            configuration.setUserName(userName);
        }
        System.out.println("请输入Mysql服务器密码");
        if (scan.hasNextLine()){
            String password = scan.nextLine();
            configuration.setPassword(password);
        }
        Connection connection = MysqlUtil.getConnection(configuration);
        MysqlUtil.executeSqlForShowDatabases(connection,configuration);
        System.out.println("请输入要连接的数据库名称");
        if (scan.hasNextLine()){
            String database = scan.nextLine();
            configuration.setDatabase(database);
        }
        MysqlUtil.executeSqlForShowTables(connection,configuration);
        System.out.println("请输入要操作的表");
        if (scan.hasNextLine()){
            String tableName = scan.nextLine();
            configuration.setTable(tableName);
        }
        System.out.println("请输入生成包名");
        if (scan.hasNextLine()){
            String packageName = scan.nextLine();
            configuration.setPackageName(packageName);
        }
        System.out.println("请输入保存的路径（比如：c:/）");
        if (scan.hasNextLine()){
            String path = scan.nextLine();
            configuration.setPath(path);
        }
        System.out.println("输入yes执行生成,否则退出");
        MysqlUtil.executeSqlForDescTable(connection,configuration);//重点
        String active = scan.nextLine();
        if ("yes".equals(active)){
            FreemarkerUtil.generateCode(configuration);
            System.out.println("生成完毕...");
            MysqlUtil.release(connection,null,null);
        }else {
            MysqlUtil.release(connection,null,null);
            System.exit(1);
        }
    }
}

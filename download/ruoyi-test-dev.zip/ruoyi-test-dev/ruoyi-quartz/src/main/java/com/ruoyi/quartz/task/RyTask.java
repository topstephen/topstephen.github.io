package com.ruoyi.quartz.task;

import cn.hutool.extra.mail.MailAccount;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.crawler.service.CrawlerService;
import com.ruoyi.elasticsearch.datacategory.entity.EsWebMsg;
import com.ruoyi.elasticsearch.datacategory.entity.WebMsgEntity;
import com.ruoyi.elasticsearch.datacategory.enums.WebMsgEnum;
import com.ruoyi.elasticsearch.datacategory.service.EsService;
import com.ruoyi.elasticsearch.datacategory.service.IEsWebMsgService;
import com.ruoyi.email.domain.EmailMsg;
import com.ruoyi.email.domain.WeatherDTO;
import com.ruoyi.email.domain.WeatherEntity;
import com.ruoyi.email.service.EmailService;
import com.ruoyi.email.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * 定时任务调度测试
 *
 * @author ruoyi
 */
@Component("ryTask")
public class RyTask {
    @Autowired
    private IEsWebMsgService iEsWebMsgService;
    @Autowired
    private EsService esService;

    public void ryMultipleParams(String s, Boolean b, Long l, Double d, Integer i) {

        System.out.println(StringUtils.format("执行多参方法： 字符串类型{}，布尔类型{}，长整型{}，浮点型{}，整形{}", s, b, l, d, i));
    }

    public void ryParams(String params) {
        System.out.println("执行有参方法：" + params);
    }

    public void ryNoParams() {
        System.out.println("1111");
        System.out.println("执行无参方法");
    }

    public void test1() {
        esService.saveAndAnalysisWebData(WebMsgEnum.FENG_JIE_XIN_WEN_WANG.getWebMsgEntity());
    }

    /**
     * @param webId
     * @return void
     * @description 通过站点ID 进行数据归集
     */
    public void saveByWebId(Long webId) {

        if (Objects.isNull(webId)) {
            throw new RuntimeException("webId 参数异常");

        }
        EsWebMsg esWebMsg = iEsWebMsgService.selectEsWebMsgById(webId);
        WebMsgEntity webMsgEntity = new WebMsgEntity();
        webMsgEntity.setWebName(esWebMsg.getWebName());
        webMsgEntity.setWebUrl(esWebMsg.getUrl());
        webMsgEntity.setXpath(esWebMsg.getXpath());
        String category = esWebMsg.getCategory();
        category = StringUtils.replace(category, ",", " ");
        webMsgEntity.setCategory(category);
        esService.saveAndAnalysisWebData(webMsgEntity);
    }

    /**
     * @return void
     * @description 统计 所有分类 所占的数量
     */
    public void count() {

        esService.countAll();
    }

    @Autowired
    private CrawlerService crawlerService;

    /**
     * @param siteName  站点名
     * @param threadNum 线程数量
     * @return void
     * @description 执行爬虫任务
     */
    public void excuteSpider(String siteName, Integer threadNum) {
        crawlerService.spiderTask(siteName, threadNum);
    }

    @Autowired
    private EmailService emailService;

    @Autowired
    private WeatherService weatherService;

    /**
     * @param name      发送人账户名
     * @param messageNo 信息编号
     * @description 定时 发送邮件任务
     */
    public void executeEmailTask(String name, String messageNo) {
        MailAccount account = emailService.initAccount(name);
        EmailMsg emailMsg = emailService.getEmailMsgByMessageNo(messageNo);
        emailService.sendMsg(account, emailMsg);
    }

    /**
     * @param name           发件人 name
     * @param city           城市
     * @param receiveAccount 收件人邮箱账号
     * @return void
     * @description s
     */
    public void exxcuteSendWeatherMsg(String name, String city, String receiveAccount) {

        WeatherEntity weatherEntity = weatherService.queryWeatherByCity(city);
        WeatherDTO weatherDTO = weatherService.getWeatherDTO(weatherEntity);
        String msgContent = weatherService.getMsgContent(weatherDTO);
        MailAccount account = emailService.initAccount(name);
        EmailMsg emailMsg = new EmailMsg();
        emailMsg.setContent(msgContent);
        emailMsg.setIshtml("否");
        emailMsg.setSubject("今日天气信息");
        emailMsg.setReceveaccount(receiveAccount);
        String filePath = weatherService.textToSpeech(msgContent);
        emailService.sendMsg(account, emailMsg, filePath);

    }

    /**
     * @param province 省份
     * @return void
     * @description 保存天眼查  公司 信息到ES
     */
    public void executeSaveTycCompany(String province) {
        esService.saveTycCompanyToEs(province);
    }

    public void executeSaveTycCompanyAll() {
        esService.saveTycCompanyToEsAll();
    }
}

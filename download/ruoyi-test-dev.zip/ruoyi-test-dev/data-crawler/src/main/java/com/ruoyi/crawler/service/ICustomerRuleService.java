package com.ruoyi.crawler.service;

import com.ruoyi.crawler.domain.CustomerRule;
import java.util.List;

/**
 * 网站爬取规则Service接口
 * 
 * @author Stephen
 * @date 2019-11-15
 */
public interface ICustomerRuleService 
{
    /**
     * 查询网站爬取规则
     * 
     * @param id 网站爬取规则ID
     * @return 网站爬取规则
     */
    public CustomerRule selectCustomerRuleById(Long id);

    /**
     * 查询网站爬取规则列表
     * 
     * @param customerRule 网站爬取规则
     * @return 网站爬取规则集合
     */
    public List<CustomerRule> selectCustomerRuleList(CustomerRule customerRule);

    /**
     * 新增网站爬取规则
     * 
     * @param customerRule 网站爬取规则
     * @return 结果
     */
    public int insertCustomerRule(CustomerRule customerRule);

    /**
     * 修改网站爬取规则
     * 
     * @param customerRule 网站爬取规则
     * @return 结果
     */
    public int updateCustomerRule(CustomerRule customerRule);

    /**
     * 批量删除网站爬取规则
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteCustomerRuleByIds(String ids);

    /**
     * 删除网站爬取规则信息
     * 
     * @param id 网站爬取规则ID
     * @return 结果
     */
    public int deleteCustomerRuleById(Long id);
}

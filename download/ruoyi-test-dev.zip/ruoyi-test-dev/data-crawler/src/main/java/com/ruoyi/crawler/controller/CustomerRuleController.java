package com.ruoyi.crawler.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.crawler.domain.CustomerRule;
import com.ruoyi.crawler.service.ICustomerRuleService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 网站爬取规则Controller
 * 
 * @author Stephen
 * @date 2019-11-15
 */
@Controller
@RequestMapping("/crawler/customerRule")
public class CustomerRuleController extends BaseController
{
    private String prefix = "crawler/customerRule";

    @Autowired
    private ICustomerRuleService customerRuleService;

    @RequiresPermissions("crawler:customerRule:view")
    @GetMapping()
    public String customerRule()
    {
        return prefix + "/customerRule";
    }

    /**
     * 查询网站爬取规则列表
     */
    @RequiresPermissions("crawler:customerRule:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(CustomerRule customerRule)
    {
        startPage();
        List<CustomerRule> list = customerRuleService.selectCustomerRuleList(customerRule);
        return getDataTable(list);
    }

    /**
     * 导出网站爬取规则列表
     */
    @RequiresPermissions("crawler:customerRule:export")
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(CustomerRule customerRule)
    {
        List<CustomerRule> list = customerRuleService.selectCustomerRuleList(customerRule);
        ExcelUtil<CustomerRule> util = new ExcelUtil<CustomerRule>(CustomerRule.class);
        return util.exportExcel(list, "customerRule");
    }

    /**
     * 新增网站爬取规则
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存网站爬取规则
     */
    @RequiresPermissions("crawler:customerRule:add")
    @Log(title = "网站爬取规则", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(CustomerRule customerRule)
    {
        return toAjax(customerRuleService.insertCustomerRule(customerRule));
    }

    /**
     * 修改网站爬取规则
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        CustomerRule customerRule = customerRuleService.selectCustomerRuleById(id);
        mmap.put("customerRule", customerRule);
        return prefix + "/edit";
    }

    /**
     * 修改保存网站爬取规则
     */
    @RequiresPermissions("crawler:customerRule:edit")
    @Log(title = "网站爬取规则", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(CustomerRule customerRule)
    {
        return toAjax(customerRuleService.updateCustomerRule(customerRule));
    }

    /**
     * 删除网站爬取规则
     */
    @RequiresPermissions("crawler:customerRule:remove")
    @Log(title = "网站爬取规则", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(customerRuleService.deleteCustomerRuleByIds(ids));
    }
}

package com.ruoyi.crawler.service.impl;

import com.ruoyi.common.core.text.Convert;
import com.ruoyi.crawler.domain.CustomerRule;
import com.ruoyi.crawler.mapper.CustomerRuleMapper;
import com.ruoyi.crawler.service.ICustomerRuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 网站爬取规则Service业务层处理
 * 
 * @author Stephen
 * @date 2019-11-15
 */
@Service
public class CustomerRuleServiceImpl implements ICustomerRuleService 
{
    @Autowired
    private CustomerRuleMapper customerRuleMapper;

    /**
     * 查询网站爬取规则
     * 
     * @param id 网站爬取规则ID
     * @return 网站爬取规则
     */
    @Override
    public CustomerRule selectCustomerRuleById(Long id)
    {
        return customerRuleMapper.selectCustomerRuleById(id);
    }

    /**
     * 查询网站爬取规则列表
     * 
     * @param customerRule 网站爬取规则
     * @return 网站爬取规则
     */
    @Override
    public List<CustomerRule> selectCustomerRuleList(CustomerRule customerRule)
    {
        return customerRuleMapper.selectCustomerRuleList(customerRule);
    }

    /**
     * 新增网站爬取规则
     * 
     * @param customerRule 网站爬取规则
     * @return 结果
     */
    @Override
    public int insertCustomerRule(CustomerRule customerRule)
    {
        return customerRuleMapper.insertCustomerRule(customerRule);
    }

    /**
     * 修改网站爬取规则
     * 
     * @param customerRule 网站爬取规则
     * @return 结果
     */
    @Override
    public int updateCustomerRule(CustomerRule customerRule)
    {
        return customerRuleMapper.updateCustomerRule(customerRule);
    }

    /**
     * 删除网站爬取规则对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteCustomerRuleByIds(String ids)
    {
        return customerRuleMapper.deleteCustomerRuleByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除网站爬取规则信息
     * 
     * @param id 网站爬取规则ID
     * @return 结果
     */
    @Override
    public int deleteCustomerRuleById(Long id)
    {
        return customerRuleMapper.deleteCustomerRuleById(id);
    }
}

package com.ruoyi.crawler.service.impl;


import com.ruoyi.crawler.domain.CustomerRule;
import com.ruoyi.crawler.mapper.CustomerRuleMapper;
import com.ruoyi.crawler.service.CrawlerService;
import com.ruoyi.crawler.sprider.MySpider;
import com.ruoyi.crawler.sprider.MysqlPipeline;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.monitor.SpiderMonitor;

import javax.management.JMException;
import java.util.List;
import java.util.UUID;

/**
 * @author Stephen
 * @description
 * @date 2019/11/15
 */
@Service
public class CrawlerServiceImpl implements CrawlerService {

    @Autowired
    private CustomerRuleMapper customerRuleMapper;

    @Override
    public void spiderTask(String siteName, Integer threadNum) {
//        String str  ="http://news.cnpc.com.cn/system/\\d{4}(\\-|\\/|.)\\d{1,2}\\1\\d{1,2}/[0-9]{9}.shtml";
        // 配置爬虫信息
        MySpider mySpider = new MySpider();
        CustomerRule customerRule = new CustomerRule();
        customerRule.setSiteName(siteName);
        List<CustomerRule> customerRuleList = customerRuleMapper.selectCustomerRuleList(customerRule);
        CustomerRule dbCustomerRule = customerRuleList.get(0);
        mySpider.setCustomerRule(dbCustomerRule);
        Spider spider = Spider.create(mySpider)
                .addUrl(dbCustomerRule.getSitePortal())
                .thread(threadNum) // 开启5个线程
                .addPipeline(new MysqlPipeline());// 自定义管道输出
        spider.setUUID(UUID.randomUUID().toString()); // 设置爬虫UUID
        // 注册monitor
        SpiderMonitor register = null;
        try {
            register = SpiderMonitor.instance().register(spider);
        } catch (JMException e) {
            e.printStackTrace();
        }
        System.out.println(register);
        spider.run();
    }
}

package com.ruoyi.crawler.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 网站爬取规则对象 customer_rule
 * 
 * @author Stephen
 * @date 2019-11-15
 */
public class CustomerRule extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** ID */
    private Long id;

    /** 站点名 */
    @Excel(name = "站点名")
    private String siteName;

    /** 站点爬虫入口 */
    @Excel(name = "站点爬虫入口")
    private String sitePortal;

    /** 内容解析Xpath规则 */
    @Excel(name = "内容解析Xpath规则")
    private String contentXpath;

    /** 标题解析Xpath规则 */
    @Excel(name = "标题解析Xpath规则")
    private String titleXpath;

    /** 发布时间解析Xpath规则 */
    @Excel(name = "发布时间解析Xpath规则")
    private String pubTimeXpath;

    /** 下一页Xpath规则 */
    @Excel(name = "下一页Xpath规则")
    private String nextPageHrefXpath;

    /** 目标页Xpath规则 */
    @Excel(name = "目标页Xpath规则")
    private String targetPageHrefXpath;

    /** 目标页URL正则表达式 */
    @Excel(name = "目标页URL正则表达式")
    private String filterRegex;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setSiteName(String siteName) 
    {
        this.siteName = siteName;
    }

    public String getSiteName() 
    {
        return siteName;
    }
    public void setSitePortal(String sitePortal) 
    {
        this.sitePortal = sitePortal;
    }

    public String getSitePortal() 
    {
        return sitePortal;
    }
    public void setContentXpath(String contentXpath) 
    {
        this.contentXpath = contentXpath;
    }

    public String getContentXpath() 
    {
        return contentXpath;
    }
    public void setTitleXpath(String titleXpath) 
    {
        this.titleXpath = titleXpath;
    }

    public String getTitleXpath() 
    {
        return titleXpath;
    }
    public void setPubTimeXpath(String pubTimeXpath) 
    {
        this.pubTimeXpath = pubTimeXpath;
    }

    public String getPubTimeXpath() 
    {
        return pubTimeXpath;
    }
    public void setNextPageHrefXpath(String nextPageHrefXpath) 
    {
        this.nextPageHrefXpath = nextPageHrefXpath;
    }

    public String getNextPageHrefXpath() 
    {
        return nextPageHrefXpath;
    }
    public void setTargetPageHrefXpath(String targetPageHrefXpath) 
    {
        this.targetPageHrefXpath = targetPageHrefXpath;
    }

    public String getTargetPageHrefXpath() 
    {
        return targetPageHrefXpath;
    }
    public void setFilterRegex(String filterRegex) 
    {
        this.filterRegex = filterRegex;
    }

    public String getFilterRegex() 
    {
        return filterRegex;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("siteName", getSiteName())
            .append("sitePortal", getSitePortal())
            .append("contentXpath", getContentXpath())
            .append("titleXpath", getTitleXpath())
            .append("pubTimeXpath", getPubTimeXpath())
            .append("nextPageHrefXpath", getNextPageHrefXpath())
            .append("targetPageHrefXpath", getTargetPageHrefXpath())
            .append("filterRegex", getFilterRegex())
            .toString();
    }
}

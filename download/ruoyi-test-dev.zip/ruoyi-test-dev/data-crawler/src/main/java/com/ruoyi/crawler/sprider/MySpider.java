package com.ruoyi.crawler.sprider;


import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.crawler.domain.CustomerRule;
import lombok.Getter;
import lombok.Setter;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.monitor.SpiderMonitor;
import us.codecraft.webmagic.processor.PageProcessor;

import javax.management.JMException;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Stephen
 * @description
 * @date 2019/11/14
 */
public class MySpider implements PageProcessor {


    public static void main(String[] args) throws JMException {

        Spider spider = Spider.create(new MySpider())
                .addUrl("http://news.cnpc.com.cn/toutiao/")
                .thread(5) // 开启5个线程
                .addPipeline(new MysqlPipeline());// 自定义管道输出
        spider.setUUID(UUID.randomUUID().toString()); // 设置爬虫UUID

        SpiderMonitor register = SpiderMonitor.instance().register(spider);
        spider.run();
        System.out.println(register);
    }

    // 部分一：抓取网站的相关配置，包括编码、抓取间隔、重试次数
    private Site site = Site.me().setRetryTimes(3).setSleepTime(100);

    @Setter
    @Getter
    private CustomerRule customerRule;


    @Override
    public Site getSite() {
        return site;
    }

    // 部分二：定义如何抽取页面信息，并保存下来
    @Override
    public void process(Page page) {
        String filterRegex = customerRule.getFilterRegex();
        String targetPageHrefXpath = customerRule.getTargetPageHrefXpath();
        String contentXpath = customerRule.getContentXpath();
        String sitePortal = customerRule.getSitePortal();
        String nextPageHrefXpath = customerRule.getNextPageHrefXpath();
        String pubTimeXpath = customerRule.getPubTimeXpath();
        String titleXpath = customerRule.getTitleXpath();

        if (!page.getUrl().regex(filterRegex).match()) {
            // 文章URL
            page.addTargetRequests(
                    page.getHtml().xpath(targetPageHrefXpath).all());
            // 翻页URL
            page.addTargetRequests(
                    page.getHtml().xpath(nextPageHrefXpath).all());
        } else {

            page.putField("content",
                    page.getHtml().xpath(contentXpath).all().toString());
            page.putField("title",
                    page.getHtml().xpath(titleXpath).all().toString());

            String pubTime = page.getHtml().xpath(pubTimeXpath).all().toString();
            page.putField("publishTime", getDateFromStr(pubTime));

            if (page.getResultItems().get("content") == null) {
                //skip this page
                page.setSkip(true);
            }
        }

    }






    /**
     * @param str
     * @return java.util.Date
     * @description 从字符串中提取日期
     */
    private static Date getDateFromStr(String str) {

        String reg = "\\d{4}(\\-|\\/|.)\\d{1,2}\\1\\d{1,2}";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(str);
        String group = null;
        while (matcher.find()) {
            group = matcher.group();

        }
        if (Objects.isNull(group)) {
            return new Date();
        }
        return DateUtils.parseDate(group);
    }

}

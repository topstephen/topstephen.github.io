package com.ruoyi.crawler.service;

public interface CrawlerService {
    public void spiderTask(String siteName, Integer threadNum);
}

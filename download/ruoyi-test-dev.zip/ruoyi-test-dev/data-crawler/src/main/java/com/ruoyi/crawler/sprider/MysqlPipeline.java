package com.ruoyi.crawler.sprider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

import java.util.Iterator;
import java.util.Map;

/**
 * @author Stephen
 * @description
 * @date 2019/11/15
 */
public class MysqlPipeline implements Pipeline {
    public static final Logger LOGGER = LoggerFactory.getLogger(MysqlPipeline.class);

    public MysqlPipeline() {
    }

    @Override
    public void process(ResultItems resultItems, Task task) {
        Map<String, Object> mapResults = resultItems.getAll();
        Iterator<Map.Entry<String, Object>> iter = mapResults.entrySet().iterator();
        Map.Entry<String, Object> entry;
        // 输出到控制台
        while (iter.hasNext()) {
            entry = iter.next();
            LOGGER.info(entry.getKey() + "：" + entry.getValue());
        }
        // 持久化

    }
}

package com.ruoyi.elasticsearch.datacategory.constant;


public class NormalContent {
    public static final String C_PLATFORM_TARGET = "platform_target";

    public static final String C_PLATFORM = "platform";

    public static final String C_CRAWLING_TIME = "crawling_time";

    public static final String C_SAVE_TIME = "save_time";

    public static final String C_PUB_TIME = "pub_time";

    public static final String[] C_PROVINCES = {"北京", "天津", "上海", "重庆", "河北", "山西", "辽宁", "吉林",
            "黑龙江", "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "海南",
            "四川", "贵州", "云南", "陕西", "甘肃", "青海", "台湾", "内蒙古", "广西", "西藏", "宁夏", "新疆"};

    public static final String[] C_TYPE = {
            "政府网站", "行业资讯", "学术智库", "综合资讯", "论坛", "上市公司公告", "房地产交易", "招聘信息", "电商商品"
    };

    public static final String C_START_TIME = "2018-03-28";

    public static final String C_AREA_CHINA = "china";

    public static final String C_AREA_WORLD = "world";


}

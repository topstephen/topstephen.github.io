package com.ruoyi.elasticsearch.datacategory.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.io.Serializable;
import java.util.Date;


@Document(indexName = "platform", type = "document")
public class PlatformEntity implements Serializable {

    @Id
    private String id;

    @Field(type = FieldType.Keyword)
    private String url;

    @Field(type = FieldType.Text)
    private String title;

    @Field(type = FieldType.Text)
    private String content;

    @Field(type = FieldType.Text)
    private String comment;

    @Field(type = FieldType.Date)
    private Date crawlingTime;

    @Field(type = FieldType.Date)
    private Date saveTime;

    @Field(type = FieldType.Date)
    private Date pubTime;

    @Field(type = FieldType.Keyword)
    private String type;

    @Field(type = FieldType.Keyword)
    private String area;

    public PlatformEntity(String url, String title, String content, String comment, Date crawlingTime,
                          Date saveTime, Date pubTime, String type, String area) {
        this.url = url;
        this.title = title;
        this.content = content;
        this.comment = comment;
        this.crawlingTime = crawlingTime;
        this.saveTime = saveTime;
        this.pubTime = pubTime;
        this.type = type;
        this.area = area;
    }

    public PlatformEntity() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getCrawlingTime() {
        return crawlingTime;
    }

    public void setCrawlingTime(Date crawlingTime) {
        this.crawlingTime = crawlingTime;
    }

    public Date getSaveTime() {
        return saveTime;
    }

    public void setSaveTime(Date saveTime) {
        this.saveTime = saveTime;
    }

    public Date getPubTime() {
        return pubTime;
    }

    public void setPubTime(Date pubTime) {
        this.pubTime = pubTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}

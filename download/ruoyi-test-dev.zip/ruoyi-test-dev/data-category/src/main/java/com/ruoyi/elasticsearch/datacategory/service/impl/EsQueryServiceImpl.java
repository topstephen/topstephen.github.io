package com.ruoyi.elasticsearch.datacategory.service.impl;

import com.ruoyi.elasticsearch.datacategory.dao.SuduCategoryRepository;
import com.ruoyi.elasticsearch.datacategory.domain.EsPageResult;
import com.ruoyi.elasticsearch.datacategory.domain.QueryPageRequest;
import com.ruoyi.elasticsearch.datacategory.entity.SuduCategoryEntity;
import com.ruoyi.elasticsearch.datacategory.enums.CategoryEnum;
import com.ruoyi.elasticsearch.datacategory.service.EsQueryService;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author Stephen
 * @description
 * @date 2019/11/6
 */
@Service
public class EsQueryServiceImpl implements EsQueryService {

    @Autowired
    private SuduCategoryRepository suduCategoryRepository;

    /**
     * @param queryPageRequest
     * @param page
     * @param size
     * @description 通过分类和标题查询
     */
    @Override
    public EsPageResult<SuduCategoryEntity> findByCondition(QueryPageRequest queryPageRequest, int page, int size) {

        BoolQueryBuilder boolQueryBuilder = new BoolQueryBuilder();
        // 封装查询条件
        if (Objects.nonNull(queryPageRequest)) {
            String category = queryPageRequest.getCategory();
            String title = queryPageRequest.getTitle();
            String webName = queryPageRequest.getWebName();
            if (StringUtils.isNotEmpty(category)) {
                MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery("category", category);
                boolQueryBuilder.must(matchQueryBuilder);
            }
            if (StringUtils.isNotEmpty(title)) {
                MatchQueryBuilder matchQueryBuilder2 = QueryBuilders.matchQuery("title", title);
                boolQueryBuilder.must(matchQueryBuilder2);
            }
            if (StringUtils.isNotEmpty(webName)) {
                MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery("webName", webName);
                boolQueryBuilder.must(matchQueryBuilder);
            }
        }

        if (page >= 1) {
            page -= 1;
        } else {
            page = 0;
        }
        PageRequest pageRequest = PageRequest.of(page, size);
        // 封装查询结果
        Page<SuduCategoryEntity> result = suduCategoryRepository.search(boolQueryBuilder, pageRequest);
        long total = result.getTotalElements();
        int totalPages = result.getTotalPages();
        List<SuduCategoryEntity> list = result.getContent();
        EsPageResult<SuduCategoryEntity> pageResult = new EsPageResult<>();
        pageResult.setResultList(list);
        pageResult.setTotal(total);
        pageResult.setTotalPages(totalPages);
        return pageResult;
    }

    @Override
    public Map<String, Long> findCategoryCount() {
        long total = 0;
        Map<String, Long> map = new LinkedHashMap<>(36);
        for (int i = 65; i <= 87; i++) {
            QueryPageRequest queryPageRequest = new QueryPageRequest();
            char x = (char) i;
            String category = x + "";
            queryPageRequest.setCategory(category);
            EsPageResult<SuduCategoryEntity> esPageResult = this.findByCondition(queryPageRequest, 1, 2);
            long count = esPageResult.getTotal();
            total += count;

            switch (category) {
                case "A":
                    map.put(CategoryEnum.A.getCategoryName(), count);
                    break;
                case "B":
                    map.put(CategoryEnum.B.getCategoryName(), count);
                    break;
                case "C":
                    map.put(CategoryEnum.C.getCategoryName(), count);
                    break;
                case "D":
                    map.put(CategoryEnum.D.getCategoryName(), count);
                    break;
                case "E":
                    map.put(CategoryEnum.E.getCategoryName(), count);
                    break;
                case "F":
                    map.put(CategoryEnum.F.getCategoryName(), count);
                    break;
                case "G":
                    map.put(CategoryEnum.G.getCategoryName(), count);
                    break;
                case "H":
                    map.put(CategoryEnum.H.getCategoryName(), count);
                    break;
                case "I":
                    map.put(CategoryEnum.I.getCategoryName(), count);
                    break;
                case "J":
                    map.put(CategoryEnum.J.getCategoryName(), count);
                    break;
                case "K":
                    map.put(CategoryEnum.K.getCategoryName(), count);
                    break;
                case "L":
                    map.put(CategoryEnum.L.getCategoryName(), count);
                    break;
                case "M":
                    map.put(CategoryEnum.M.getCategoryName(), count);
                    break;
                case "N":
                    map.put(CategoryEnum.N.getCategoryName(), count);
                    break;
                case "O":
                    map.put(CategoryEnum.O.getCategoryName(), count);
                    break;
                case "P":
                    map.put(CategoryEnum.P.getCategoryName(), count);
                    break;
                case "Q":
                    map.put(CategoryEnum.Q.getCategoryName(), count);
                    break;
                case "R":
                    map.put(CategoryEnum.R.getCategoryName(), count);
                    break;
                case "S":
                    map.put(CategoryEnum.S.getCategoryName(), count);
                    break;
                case "T":
                    map.put(CategoryEnum.T.getCategoryName(), count);
                    break;
                case "U":
                    map.put(CategoryEnum.U.getCategoryName(), count);
                case "V":
                    map.put(CategoryEnum.V.getCategoryName(), count);
                    break;
                case "W":
                    map.put(CategoryEnum.W.getCategoryName(), count);
                    break;
            }


        }
        map.put("总量", total);
        return map;
    }

}

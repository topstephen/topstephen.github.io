package com.ruoyi.elasticsearch.datacategory.entity;

import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 各网站在ES中的数据量对象 tb_es_count
 * 
 * @author Stephen
 * @date 2019-11-04
 */
public class EsCount extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** ID */
    private Long id;

    /** 网站名 */
    @Excel(name = "网站名")
    private String esWebName;

    /** 提取内容的xpath规则 */
    @Excel(name = "提取内容的xpath规则")
    private String esXpath;

    /** 网站地址 */
    @Excel(name = "网站地址")
    private String esUrl;

    /** 预留字段1 */
    @Excel(name = "预留字段1")
    private String esStandby1;

    /** 预留字段2 */
    @Excel(name = "预留字段2")
    private String esStandby2;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setEsWebName(String esWebName) 
    {
        this.esWebName = esWebName;
    }

    public String getEsWebName() 
    {
        return esWebName;
    }
    public void setEsXpath(String esXpath) 
    {
        this.esXpath = esXpath;
    }

    public String getEsXpath() 
    {
        return esXpath;
    }
    public void setEsUrl(String esUrl) 
    {
        this.esUrl = esUrl;
    }

    public String getEsUrl() 
    {
        return esUrl;
    }
    public void setEsStandby1(String esStandby1) 
    {
        this.esStandby1 = esStandby1;
    }

    public String getEsStandby1() 
    {
        return esStandby1;
    }
    public void setEsStandby2(String esStandby2) 
    {
        this.esStandby2 = esStandby2;
    }

    public String getEsStandby2() 
    {
        return esStandby2;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("esWebName", getEsWebName())
            .append("esXpath", getEsXpath())
            .append("esUrl", getEsUrl())
            .append("esStandby1", getEsStandby1())
            .append("esStandby2", getEsStandby2())
            .toString();
    }
}

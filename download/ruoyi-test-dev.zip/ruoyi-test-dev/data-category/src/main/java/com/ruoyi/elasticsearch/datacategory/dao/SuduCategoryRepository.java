package com.ruoyi.elasticsearch.datacategory.dao;

import com.ruoyi.elasticsearch.datacategory.entity.SuduCategoryEntity;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface SuduCategoryRepository extends ElasticsearchRepository<SuduCategoryEntity, String> {
}

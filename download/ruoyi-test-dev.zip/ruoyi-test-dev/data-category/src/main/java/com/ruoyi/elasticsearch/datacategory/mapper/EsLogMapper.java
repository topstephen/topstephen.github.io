package com.ruoyi.elasticsearch.datacategory.mapper;


import com.ruoyi.elasticsearch.datacategory.entity.EsLog;

import java.util.List;

/**
 * 数据分类转存ES日志Mapper接口
 * 
 * @author Stephen
 * @date 2019-11-03
 */
public interface EsLogMapper 
{
    /**
     * 查询数据分类转存ES日志
     * 
     * @param id 数据分类转存ES日志ID
     * @return 数据分类转存ES日志
     */
    public EsLog selectEsLogById(Long id);

    /**
     * 查询数据分类转存ES日志列表
     * 
     * @param esLog 数据分类转存ES日志
     * @return 数据分类转存ES日志集合
     */
    public List<EsLog> selectEsLogList(EsLog esLog);

    /**
     * 新增数据分类转存ES日志
     * 
     * @param esLog 数据分类转存ES日志
     * @return 结果
     */
    public int insertEsLog(EsLog esLog);

    /**
     * 修改数据分类转存ES日志
     * 
     * @param esLog 数据分类转存ES日志
     * @return 结果
     */
    public int updateEsLog(EsLog esLog);

    /**
     * 删除数据分类转存ES日志
     * 
     * @param id 数据分类转存ES日志ID
     * @return 结果
     */
    public int deleteEsLogById(Long id);

    /**
     * 批量删除数据分类转存ES日志
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteEsLogByIds(String[] ids);
}

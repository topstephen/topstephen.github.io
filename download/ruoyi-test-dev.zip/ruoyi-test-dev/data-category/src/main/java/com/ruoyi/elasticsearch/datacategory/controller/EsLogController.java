package com.ruoyi.elasticsearch.datacategory.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.elasticsearch.datacategory.entity.EsLog;
import com.ruoyi.elasticsearch.datacategory.service.IEsLogService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 数据分类转存ES日志Controller
 * 
 * @author Stephen
 * @date 2019-11-03
 */
@Controller
@RequestMapping("/system/esLog")
public class EsLogController extends BaseController
{
    private String prefix = "system/esLog";

    @Autowired
    private IEsLogService esLogService;

    @RequiresPermissions("system:esLog:view")
    @GetMapping()
    public String esLog()
    {
        return prefix + "/esLog";
    }

    /**
     * 查询数据分类转存ES日志列表
     */
    @RequiresPermissions("system:esLog:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(EsLog esLog)
    {
        startPage();
            List<EsLog> list = esLogService.selectEsLogList(esLog);
        return getDataTable(list);
    }

    /**
     * 导出数据分类转存ES日志列表
     */
    @RequiresPermissions("system:esLog:export")
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(EsLog esLog)
    {
        List<EsLog> list = esLogService.selectEsLogList(esLog);
        ExcelUtil<EsLog> util = new ExcelUtil<EsLog>(EsLog.class);
        return util.exportExcel(list, "esLog");
    }

    /**
     * 新增数据分类转存ES日志
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存数据分类转存ES日志
     */
    @RequiresPermissions("system:esLog:add")
    @Log(title = "数据分类转存ES日志", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(EsLog esLog)
    {
        return toAjax(esLogService.insertEsLog(esLog));
    }

    /**
     * 修改数据分类转存ES日志
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        EsLog esLog = esLogService.selectEsLogById(id);
        mmap.put("esLog", esLog);
        return prefix + "/edit";
    }

    /**
     * 修改保存数据分类转存ES日志
     */
    @RequiresPermissions("system:esLog:edit")
    @Log(title = "数据分类转存ES日志", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(EsLog esLog)
    {
        return toAjax(esLogService.updateEsLog(esLog));
    }

    /**
     * 删除数据分类转存ES日志
     */
    @RequiresPermissions("system:esLog:remove")
    @Log(title = "数据分类转存ES日志", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(esLogService.deleteEsLogByIds(ids));
    }
}

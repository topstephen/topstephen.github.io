package com.ruoyi.elasticsearch.datacategory.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.elasticsearch.datacategory.mapper.TycCompanyMapper;
import com.ruoyi.elasticsearch.datacategory.domain.TycCompany;
import com.ruoyi.elasticsearch.datacategory.service.ITycCompanyService;
import com.ruoyi.common.core.text.Convert;

/**
 * 天眼查网站上-公司信息Service业务层处理
 * 
 * @author Stephen
 * @date 2019-11-21
 */
@Service
public class TycCompanyServiceImpl implements ITycCompanyService 
{
    @Autowired
    private TycCompanyMapper tycCompanyMapper;

    /**
     * 查询天眼查网站上-公司信息
     * 
     * @param id 天眼查网站上-公司信息ID
     * @return 天眼查网站上-公司信息
     */
    @Override
    public TycCompany selectTycCompanyById(Long id)
    {
        return tycCompanyMapper.selectTycCompanyById(id);
    }

    /**
     * 查询天眼查网站上-公司信息列表
     * 
     * @param tycCompany 天眼查网站上-公司信息
     * @return 天眼查网站上-公司信息
     */
    @Override
    public List<TycCompany> selectTycCompanyList(TycCompany tycCompany)
    {
        return tycCompanyMapper.selectTycCompanyList(tycCompany);
    }

    /**
     * 新增天眼查网站上-公司信息
     * 
     * @param tycCompany 天眼查网站上-公司信息
     * @return 结果
     */
    @Override
    public int insertTycCompany(TycCompany tycCompany)
    {
        return tycCompanyMapper.insertTycCompany(tycCompany);
    }

    /**
     * 修改天眼查网站上-公司信息
     * 
     * @param tycCompany 天眼查网站上-公司信息
     * @return 结果
     */
    @Override
    public int updateTycCompany(TycCompany tycCompany)
    {
        return tycCompanyMapper.updateTycCompany(tycCompany);
    }

    /**
     * 删除天眼查网站上-公司信息对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteTycCompanyByIds(String ids)
    {
        return tycCompanyMapper.deleteTycCompanyByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除天眼查网站上-公司信息信息
     * 
     * @param id 天眼查网站上-公司信息ID
     * @return 结果
     */
    @Override
    public int deleteTycCompanyById(Long id)
    {
        return tycCompanyMapper.deleteTycCompanyById(id);
    }
}

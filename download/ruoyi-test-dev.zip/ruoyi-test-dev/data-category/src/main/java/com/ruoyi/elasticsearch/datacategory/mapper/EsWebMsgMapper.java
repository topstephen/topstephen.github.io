package com.ruoyi.elasticsearch.datacategory.mapper;


import com.ruoyi.elasticsearch.datacategory.entity.EsWebMsg;

import java.util.List;

/**
 * 网站信息Mapper接口
 * 
 * @author Stephen
 * @date 2019-11-03
 */
public interface EsWebMsgMapper 
{
    /**
     * 查询网站信息
     * 
     * @param id 网站信息ID
     * @return 网站信息
     */
    public EsWebMsg selectEsWebMsgById(Long id);

    /**
     * 查询网站信息列表
     * 
     * @param esWebMsg 网站信息
     * @return 网站信息集合
     */
    public List<EsWebMsg> selectEsWebMsgList(EsWebMsg esWebMsg);

    /**
     * 新增网站信息
     * 
     * @param esWebMsg 网站信息
     * @return 结果
     */
    public int insertEsWebMsg(EsWebMsg esWebMsg);

    /**
     * 修改网站信息
     * 
     * @param esWebMsg 网站信息
     * @return 结果
     */
    public int updateEsWebMsg(EsWebMsg esWebMsg);

    /**
     * 删除网站信息
     * 
     * @param id 网站信息ID
     * @return 结果
     */
    public int deleteEsWebMsgById(Long id);

    /**
     * 批量删除网站信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteEsWebMsgByIds(String[] ids);
}

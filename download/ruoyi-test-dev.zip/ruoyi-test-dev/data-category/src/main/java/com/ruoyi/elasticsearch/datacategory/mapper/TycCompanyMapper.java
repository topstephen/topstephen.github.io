package com.ruoyi.elasticsearch.datacategory.mapper;

import com.ruoyi.elasticsearch.datacategory.domain.TycCompany;
import java.util.List;

/**
 * 天眼查网站上-公司信息Mapper接口
 * 
 * @author Stephen
 * @date 2019-11-21
 */
public interface TycCompanyMapper 
{
    /**
     * 查询天眼查网站上-公司信息
     * 
     * @param id 天眼查网站上-公司信息ID
     * @return 天眼查网站上-公司信息
     */
    public TycCompany selectTycCompanyById(Long id);

    /**
     * 查询天眼查网站上-公司信息列表
     * 
     * @param tycCompany 天眼查网站上-公司信息
     * @return 天眼查网站上-公司信息集合
     */
    public List<TycCompany> selectTycCompanyList(TycCompany tycCompany);

    /**
     * 新增天眼查网站上-公司信息
     * 
     * @param tycCompany 天眼查网站上-公司信息
     * @return 结果
     */
    public int insertTycCompany(TycCompany tycCompany);

    /**
     * 修改天眼查网站上-公司信息
     * 
     * @param tycCompany 天眼查网站上-公司信息
     * @return 结果
     */
    public int updateTycCompany(TycCompany tycCompany);

    /**
     * 删除天眼查网站上-公司信息
     * 
     * @param id 天眼查网站上-公司信息ID
     * @return 结果
     */
    public int deleteTycCompanyById(Long id);

    /**
     * 批量删除天眼查网站上-公司信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTycCompanyByIds(String[] ids);
}

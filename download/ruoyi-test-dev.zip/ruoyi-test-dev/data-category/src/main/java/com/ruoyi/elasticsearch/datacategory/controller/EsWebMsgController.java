package com.ruoyi.elasticsearch.datacategory.controller;


import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.elasticsearch.datacategory.entity.EsWebMsg;
import com.ruoyi.elasticsearch.datacategory.service.IEsWebMsgService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 网站信息Controller
 * 
 * @author Stephen
 * @date 2019-11-03
 */
@Controller
@RequestMapping("/system/msg")
public class EsWebMsgController extends BaseController
{
    private String prefix = "system/msg";

    @Autowired
    private IEsWebMsgService esWebMsgService;

    @RequiresPermissions("system:msg:view")
    @GetMapping()
    public String msg()
    {
        return prefix + "/msg";
    }

    /**
     * 查询网站信息列表
     */
    @RequiresPermissions("system:msg:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(EsWebMsg esWebMsg)
    {
        startPage();
        List<EsWebMsg> list = esWebMsgService.selectEsWebMsgList(esWebMsg);
        return getDataTable(list);
    }

    /**
     * 导出网站信息列表
     */
    @RequiresPermissions("system:msg:export")
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(EsWebMsg esWebMsg)
    {
        List<EsWebMsg> list = esWebMsgService.selectEsWebMsgList(esWebMsg);
        ExcelUtil<EsWebMsg> util = new ExcelUtil<EsWebMsg>(EsWebMsg.class);
        return util.exportExcel(list, "msg");
    }

    /**
     * 新增网站信息
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存网站信息
     */
    @RequiresPermissions("system:msg:add")
    @Log(title = "网站信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(EsWebMsg esWebMsg)
    {
        return toAjax(esWebMsgService.insertEsWebMsg(esWebMsg));
    }

    /**
     * 修改网站信息
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        EsWebMsg esWebMsg = esWebMsgService.selectEsWebMsgById(id);
        mmap.put("esWebMsg", esWebMsg);
        return prefix + "/edit";
    }

    /**
     * 修改保存网站信息
     */
    @RequiresPermissions("system:msg:edit")
    @Log(title = "网站信息", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(EsWebMsg esWebMsg)
    {
        return toAjax(esWebMsgService.updateEsWebMsg(esWebMsg));
    }

    /**
     * 删除网站信息
     */
    @RequiresPermissions("system:msg:remove")
    @Log(title = "网站信息", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(esWebMsgService.deleteEsWebMsgByIds(ids));
    }
}

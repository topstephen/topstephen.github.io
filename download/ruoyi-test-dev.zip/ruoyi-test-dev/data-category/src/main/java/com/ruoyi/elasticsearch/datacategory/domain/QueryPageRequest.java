package com.ruoyi.elasticsearch.datacategory.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @author Stephen
 * @description
 * @date 2019/11/6
 */
@ApiModel("查询条件实体")
public class QueryPageRequest {
    @ApiModelProperty("分类")
    private String category;
    @ApiModelProperty("标题")
    private String title;
    @ApiModelProperty("网站名")
    private String webName;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getWebName() {
        return webName;
    }

    public void setWebName(String webName) {
        this.webName = webName;
    }
}

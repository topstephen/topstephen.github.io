package com.ruoyi.elasticsearch.datacategory.controller;

import com.ruoyi.elasticsearch.datacategory.domain.EsPageResult;
import com.ruoyi.elasticsearch.datacategory.domain.QueryPageRequest;
import com.ruoyi.elasticsearch.datacategory.entity.SuduCategoryEntity;
import com.ruoyi.elasticsearch.datacategory.service.EsQueryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Stephen
 * @description
 * @date 2019/11/6
 */
@Api("用户信息管理")
@RestController
@RequestMapping("/es")
public class EsQueryController {
    @Autowired
    private EsQueryService queryService;


    /**
     * showdoc
     *
     * @param page     是 int 页码
     * @param size     是 int 每页记录数
     * @param category 否 String 分类
     * @param title    否 String 标题
     * @return {"code":200,"esPageResult":{"total":670677,"totalPages":335339,"resultList":[{"id":"AWqQv-8597Q0F-0n9j-3","url":"http://cq.people.com.cn/GB/365413/news/201819/201819832225474424.htm","title":"保险业严监管仍在持续 新年首周开出千万罚单--重庆频道--人民网","content":"毫无疑问，2017年是保险行业的严监管之年，“1+4”号文以及相关规章制度大量下发，各种检查、罚单、监管函数量激增。据统计，2017年仅保监会官网公布的相关政策及通知就达60多份，与人身险或财产险相关的文件也均超过200份。","comment":"null","crawlingTime":"2019-05-07 13:24:18","saveTime":"2019-11-05 14:08:02","pubTime":"2019-05-07 13:24:18","type":"综合资讯","area":"重庆","category":"B","webName":"人民网重庆"},{"id":"AWqQwFH1qRN1x_12eq6E","url":"http://cq.people.com.cn/GB/365412/news/201842/2018421424519016142.htm","title":"33位东盟优秀企业家抱团来渝洽谈合作--重庆频道--人民网","content":"　　人民网重庆4月2日电（胡虹）记者2日从重庆市商委获悉，在近期举行的中外企业合作对接会暨东盟-重庆国际经贸合作交流酒会上，33位外商企业家抱团来渝意向投入2亿美元发展进出口贸易、服务贸易及实体经济投资，并与重庆本土优秀企业面对面洽谈合作，期待达成长期战略合作。”","comment":"null","crawlingTime":"2019-05-07 13:24:44","saveTime":"2019-11-05 14:08:02","pubTime":"2019-05-07 13:24:44","type":"综合资讯","area":"重庆","category":"A","webName":"人民网重庆"}]}}
     * @catalog ES数据归集查询API
     * @title ES数据归集查询
     * @description 根据分类和标题查询
     * @method get
     * @url /es/findByCondition
     * @return_param title String 文章标题
     * @return_param content String 文章内容
     * @return_param total Long 总记录数
     * @return_param url String 网站地址
     * @return_param crawlingTime Date 爬取时间
     * @return_param pubTime Date 发布时间
     * @return_param saveTime Date 保存时间
     * @return_param type String 网站类型
     * @return_param area String 区域
     * @return_param category String 分类
     * @return_param webName String 网站名
     * @number 2
     */
    @ApiOperation("根据类型和标题查询数据")
    @GetMapping("/findByCondition/{page}/{size}")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", value = "页码", required = true, paramType = "path", dataType = "int"),
            @ApiImplicitParam(name = "size", value = "每页记录数", required = true, paramType = "path", dataType = "int"),
    })
    public Map<String, Object> findByCondition(QueryPageRequest queryPageRequest, @PathVariable("page") int page, @PathVariable("size") int size) {
        EsPageResult<SuduCategoryEntity> esPageResult = queryService.findByCondition(queryPageRequest, page, size);
        Map<String, Object> map = new HashMap<>();
        map.put("esPageResult", esPageResult);
        map.put("code", 200);
        return map;
    }

    /**
     * showdoc
     *
     * @return {"投融资":377676,"消费类":475174,"进出口":88041,"电子商务":202186,"招投标":25,"金融服务":225960,"企业信息":128321,"劳动就业类":170597,"资源环境":93113,"交通地理":33901,"卫星灯光":0,"对外贸易类":80946,"资讯报道类":628590,"评论及经济观点类":155391,"自媒体":185888,"基础统计类":50679,"政策战略与规划类":318197,"社会分配类":0,"财政收支类":14995,"思想与文化发展软实力类":524248,"民生质量类":111941,"科技与创新类":328019,"房产信息类":157381,"总量":4351269}
     * @catalog ES数据归集查询API
     * @title 查询各个分类数据数量和总量
     * @description 查询各个分类数据数量和总量API
     * @method get
     * @url /es/findCategoryCount
     * @number 3
     */
    @ApiOperation("查询各个类型的数量")
    @GetMapping("/findCategoryCount")
    public Map<String, Long> findCategoryCount() {
        return queryService.findCategoryCount();
    }


    /**
     * showdoc
     *
     * @return {"code":200,"esIndexCountList":[{"health":"green","status":"open","index":"platform","uuid":"5WhwM75aT5u3je1mVRJrvA","pri":"5","rep":"1","docsCount":"1","docsDeleted":"0","storeSize":"13.7kb","priStoreSize":"6.8kb"},{"health":"green","status":"open","index":"platform_target","uuid":"DJ7dTXyUTdGqtMoPjcwIxA","pri":"5","rep":"1","docsCount":"1286372","docsDeleted":"0","storeSize":"153.6gb","priStoreSize":"76.8gb"}]}
     * @catalog 查询ES中各索引数据量API
     * @title 查询ES中各索引数据量
     * @description 查询ES中各索引数据量API
     * @method get
     * @return_param health String 健康状态
     * @return_param status String 索引是否开启
     * @return_param index String 索引
     * @return_param uuid String UUID
     * @return_param pri String 主分片
     * @return_param rep String 副本分片
     * @return_param docsCount String 文档数
     * @return_param docsDeleted String 删除文档数
     * @return_param storeSize String 存储大小
     * @return_param priStoreSize String 主分片存储大小
     * @url /es/findAllIndexCount
     * @number 4
     */

}
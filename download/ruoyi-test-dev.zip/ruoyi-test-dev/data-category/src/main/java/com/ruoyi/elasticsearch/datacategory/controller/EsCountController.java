package com.ruoyi.elasticsearch.datacategory.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.elasticsearch.datacategory.entity.EsCount;
import com.ruoyi.elasticsearch.datacategory.service.IEsCountService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 各网站在ES中的数据量Controller
 * 
 * @author Stephen
 * @date 2019-11-04
 */
@Controller
@RequestMapping("/system/count")
public class EsCountController extends BaseController
{
    private String prefix = "system/count";

    @Autowired
    private IEsCountService esCountService;

    @RequiresPermissions("system:count:view")
    @GetMapping()
    public String count()
    {
        return prefix + "/count";
    }

    /**
     * 查询各网站在ES中的数据量列表
     */
    @RequiresPermissions("system:count:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(EsCount esCount)
    {
        startPage();
        List<EsCount> list = esCountService.selectEsCountList(esCount);
        return getDataTable(list);
    }

    /**
     * 导出各网站在ES中的数据量列表
     */
    @RequiresPermissions("system:count:export")
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(EsCount esCount)
    {
        List<EsCount> list = esCountService.selectEsCountList(esCount);
        ExcelUtil<EsCount> util = new ExcelUtil<EsCount>(EsCount.class);
        return util.exportExcel(list, "count");
    }

    /**
     * 新增各网站在ES中的数据量
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存各网站在ES中的数据量
     */
    @RequiresPermissions("system:count:add")
    @Log(title = "各网站在ES中的数据量", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(EsCount esCount)
    {
        return toAjax(esCountService.insertEsCount(esCount));
    }

    /**
     * 修改各网站在ES中的数据量
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        EsCount esCount = esCountService.selectEsCountById(id);
        mmap.put("esCount", esCount);
        return prefix + "/edit";
    }

    /**
     * 修改保存各网站在ES中的数据量
     */
    @RequiresPermissions("system:count:edit")
    @Log(title = "各网站在ES中的数据量", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(EsCount esCount)
    {
        return toAjax(esCountService.updateEsCount(esCount));
    }

    /**
     * 删除各网站在ES中的数据量
     */
    @RequiresPermissions("system:count:remove")
    @Log(title = "各网站在ES中的数据量", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(esCountService.deleteEsCountByIds(ids));
    }
}

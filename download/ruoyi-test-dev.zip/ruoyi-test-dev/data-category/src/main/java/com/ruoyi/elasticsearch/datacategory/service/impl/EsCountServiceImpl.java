package com.ruoyi.elasticsearch.datacategory.service.impl;

import com.ruoyi.common.core.text.Convert;
import com.ruoyi.elasticsearch.datacategory.entity.EsCount;
import com.ruoyi.elasticsearch.datacategory.mapper.EsCountMapper;
import com.ruoyi.elasticsearch.datacategory.service.IEsCountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 各网站在ES中的数据量Service业务层处理
 * 
 * @author Stephen
 * @date 2019-11-04
 */
@Service
public class EsCountServiceImpl implements IEsCountService 
{
    @Autowired
    private EsCountMapper esCountMapper;

    /**
     * 查询各网站在ES中的数据量
     * 
     * @param id 各网站在ES中的数据量ID
     * @return 各网站在ES中的数据量
     */
    @Override
    public EsCount selectEsCountById(Long id)
    {
        return esCountMapper.selectEsCountById(id);
    }

    /**
     * 查询各网站在ES中的数据量列表
     * 
     * @param esCount 各网站在ES中的数据量
     * @return 各网站在ES中的数据量
     */
    @Override
    public List<EsCount> selectEsCountList(EsCount esCount)
    {
        return esCountMapper.selectEsCountList(esCount);
    }

    /**
     * 新增各网站在ES中的数据量
     * 
     * @param esCount 各网站在ES中的数据量
     * @return 结果
     */
    @Override
    public int insertEsCount(EsCount esCount)
    {
        return esCountMapper.insertEsCount(esCount);
    }

    /**
     * 修改各网站在ES中的数据量
     * 
     * @param esCount 各网站在ES中的数据量
     * @return 结果
     */
    @Override
    public int updateEsCount(EsCount esCount)
    {
        return esCountMapper.updateEsCount(esCount);
    }

    /**
     * 删除各网站在ES中的数据量对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteEsCountByIds(String ids)
    {
        return esCountMapper.deleteEsCountByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除各网站在ES中的数据量信息
     * 
     * @param id 各网站在ES中的数据量ID
     * @return 结果
     */
    @Override
    public int deleteEsCountById(Long id)
    {
        return esCountMapper.deleteEsCountById(id);
    }
}

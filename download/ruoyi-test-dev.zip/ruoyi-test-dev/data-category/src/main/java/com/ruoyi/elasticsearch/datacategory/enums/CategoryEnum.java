package com.ruoyi.elasticsearch.datacategory.enums;

/****
 * 分类mapping
 */
public enum CategoryEnum {
    A("投融资",'A'),
    B("消费类",'B'),
    C("进出口",'C'),
    D("电子商务",'D'),
    E("招投标",'E'),
    F("金融服务",'F'),
    G("企业信息",'G'),
    H("劳动就业类",'H'),
    I("资源环境",'I'),
    J("交通地理",'J'),
    K("卫星灯光",'K'),
    L("对外贸易类",'L'),
    M("资讯报道类",'M'),
    N("评论及经济观点类",'N'),
    O("自媒体",'O'),
    P("基础统计类",'P'),
    Q("政策战略与规划类",'Q'),
    R("社会分配类",'R'),
    S("财政收支类",'S'),
    T("思想与文化发展软实力类",'T'),
    U("民生质量类",'U'),
    V("科技与创新类",'V'),
    W("房产信息类",'W')
    ;
    private char aChar;
    private String categoryName;

    CategoryEnum(String categoryName, char aChar) {
        this.aChar = aChar;
        this.categoryName = categoryName;
    }

    public char getaChar() {
        return aChar;
    }

    public String getCategoryName() {
        return categoryName;
    }
}

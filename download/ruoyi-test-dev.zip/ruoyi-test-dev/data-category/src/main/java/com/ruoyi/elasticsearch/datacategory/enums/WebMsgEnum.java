package com.ruoyi.elasticsearch.datacategory.enums;

import com.ruoyi.elasticsearch.datacategory.entity.WebMsgEntity;

public enum WebMsgEnum {
    FDXWW("丰都新闻网ch",new WebMsgEntity("//div[@id='fontzoom']//span[@style!='display:none']//text()","丰都新闻网ch","www.gcfd.cn","")),
    YZXWW("渝中新闻网ch",new WebMsgEntity("//div[@id='content']//text()","渝中新闻网ch","www.cqyznews.com","")),
    FENG_JIE_XIN_WEN_WANG("奉节新闻网ch",new WebMsgEntity("//div[@class=\"article-detail-inner article-relevance w660 ov\"]//text()","奉节新闻网ch","www.xfjw.net","")),

    FU_LIN_WANG("涪陵网ch",new WebMsgEntity("//div[@class='zhengwen']//p/span/text()","涪陵网ch","www.fulingwx.com","")),
    DIAN_JIANG_XIN_WEN_WANG("垫江新闻网ch",new WebMsgEntity("//div[@class='post-desc text-justify']//text()","垫江新闻网ch","news.cqdj.gov.cn","")),
    BA_NAN_WANG("巴南网规则提取ch",new WebMsgEntity("//td/font//text()","巴南网ch","www.bn.cq.cn",""));












    private WebMsgEntity webMsgEntity; //爬取的站点信息
    private String description ; // 描述
    WebMsgEnum(String description ,WebMsgEntity webMsgEntity) {
        this.webMsgEntity = webMsgEntity;
        this.description = description;
    }

    public WebMsgEntity getWebMsgEntity() {
        return webMsgEntity;
    }

    public String getDescription() {
        return description;
    }
}

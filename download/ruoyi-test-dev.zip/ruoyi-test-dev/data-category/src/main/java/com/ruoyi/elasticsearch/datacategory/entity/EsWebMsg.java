package com.ruoyi.elasticsearch.datacategory.entity;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 网站信息对象 tb_es_web_msg
 * 
 * @author Stephen
 * @date 2019-11-03
 */
public class EsWebMsg extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** ID */
    private Long id;

    /** 网站名 */
    @Excel(name = "网站名")
    private String webName;

    /** 提取内容的xpath规则 */
    @Excel(name = "提取内容的xpath规则")
    private String xpath;

    /** 网站地址 */
    @Excel(name = "网站地址")
    private String url;

    /** Python工程文件名 */
    @Excel(name = "Python工程文件名")
    private String belongTo;

    /** 分类 */
    @Excel(name = "分类")
    private String category;

    /** 状态(已分类，未分类) */
    @Excel(name = "状态(已分类，未分类)")
    private String status;

    /** 预留字段1 */
    @Excel(name = "预留字段1")
    private String standby1;

    /** 预留字段2 */
    @Excel(name = "预留字段2")
    private String standby2;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setWebName(String webName) 
    {
        this.webName = webName;
    }

    public String getWebName() 
    {
        return webName;
    }
    public void setXpath(String xpath) 
    {
        this.xpath = xpath;
    }

    public String getXpath() 
    {
        return xpath;
    }
    public void setUrl(String url) 
    {
        this.url = url;
    }

    public String getUrl() 
    {
        return url;
    }
    public void setBelongTo(String belongTo) 
    {
        this.belongTo = belongTo;
    }

    public String getBelongTo() 
    {
        return belongTo;
    }
    public void setCategory(String category) 
    {
        this.category = category;
    }

    public String getCategory() 
    {
        return category;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }
    public void setStandby1(String standby1) 
    {
        this.standby1 = standby1;
    }

    public String getStandby1() 
    {
        return standby1;
    }
    public void setStandby2(String standby2) 
    {
        this.standby2 = standby2;
    }

    public String getStandby2() 
    {
        return standby2;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("webName", getWebName())
            .append("xpath", getXpath())
            .append("url", getUrl())
            .append("belongTo", getBelongTo())
            .append("category", getCategory())
            .append("status", getStatus())
            .append("standby1", getStandby1())
            .append("standby2", getStandby2())
            .toString();
    }
}

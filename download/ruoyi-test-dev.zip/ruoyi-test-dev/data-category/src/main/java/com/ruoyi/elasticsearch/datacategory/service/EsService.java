package com.ruoyi.elasticsearch.datacategory.service;

import com.ruoyi.elasticsearch.datacategory.entity.WebMsgEntity;

/**
 * @author Stephen
 * @description
 * @date 2019/10/30
 */
public interface EsService {
    public void saveAndAnalysisWebData(WebMsgEntity webMsgEntity);
    public long countAll();
    public void saveTycCompanyToEs(String province);
    public void saveTycCompanyToEsAll();
}

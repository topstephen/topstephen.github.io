package com.ruoyi.elasticsearch.datacategory.service.impl;


import com.ruoyi.common.core.text.Convert;
import com.ruoyi.elasticsearch.datacategory.entity.EsWebMsg;
import com.ruoyi.elasticsearch.datacategory.mapper.EsWebMsgMapper;
import com.ruoyi.elasticsearch.datacategory.service.IEsWebMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 网站信息Service业务层处理
 * 
 * @author Stephen
 * @date 2019-11-03
 */
@Service
public class EsWebMsgServiceImpl implements IEsWebMsgService
{
    @Autowired
    private EsWebMsgMapper esWebMsgMapper;

    /**
     * 查询网站信息
     * 
     * @param id 网站信息ID
     * @return 网站信息
     */
    @Override
    public EsWebMsg selectEsWebMsgById(Long id)
    {
        return esWebMsgMapper.selectEsWebMsgById(id);
    }

    /**
     * 查询网站信息列表
     * 
     * @param esWebMsg 网站信息
     * @return 网站信息
     */
    @Override
    public List<EsWebMsg> selectEsWebMsgList(EsWebMsg esWebMsg)
    {
        return esWebMsgMapper.selectEsWebMsgList(esWebMsg);
    }

    /**
     * 新增网站信息
     * 
     * @param esWebMsg 网站信息
     * @return 结果
     */
    @Override
    public int insertEsWebMsg(EsWebMsg esWebMsg)
    {
        return esWebMsgMapper.insertEsWebMsg(esWebMsg);
    }

    /**
     * 修改网站信息
     * 
     * @param esWebMsg 网站信息
     * @return 结果
     */
    @Override
    public int updateEsWebMsg(EsWebMsg esWebMsg)
    {
        return esWebMsgMapper.updateEsWebMsg(esWebMsg);
    }

    /**
     * 删除网站信息对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteEsWebMsgByIds(String ids)
    {
        return esWebMsgMapper.deleteEsWebMsgByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除网站信息信息
     * 
     * @param id 网站信息ID
     * @return 结果
     */
    @Override
    public int deleteEsWebMsgById(Long id)
    {
        return esWebMsgMapper.deleteEsWebMsgById(id);
    }
}

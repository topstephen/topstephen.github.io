package com.ruoyi.elasticsearch.datacategory.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.elasticsearch.datacategory.domain.TycCompany;
import com.ruoyi.elasticsearch.datacategory.service.ITycCompanyService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 天眼查网站上-公司信息Controller
 * 
 * @author Stephen
 * @date 2019-11-21
 */
@Controller
@RequestMapping("/datacategory/company")
public class TycCompanyController extends BaseController
{
    private String prefix = "datacategory/company";

    @Autowired
    private ITycCompanyService tycCompanyService;

    @RequiresPermissions("datacategory:company:view")
    @GetMapping()
    public String company()
    {
        return prefix + "/company";
    }

    /**
     * 查询天眼查网站上-公司信息列表
     */
    @RequiresPermissions("datacategory:company:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(TycCompany tycCompany)
    {
        startPage();
        List<TycCompany> list = tycCompanyService.selectTycCompanyList(tycCompany);
        return getDataTable(list);
    }

    /**
     * 导出天眼查网站上-公司信息列表
     */
    @RequiresPermissions("datacategory:company:export")
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(TycCompany tycCompany)
    {
        List<TycCompany> list = tycCompanyService.selectTycCompanyList(tycCompany);
        ExcelUtil<TycCompany> util = new ExcelUtil<TycCompany>(TycCompany.class);
        return util.exportExcel(list, "company");
    }

    /**
     * 新增天眼查网站上-公司信息
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存天眼查网站上-公司信息
     */
    @RequiresPermissions("datacategory:company:add")
    @Log(title = "天眼查网站上-公司信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(TycCompany tycCompany)
    {
        return toAjax(tycCompanyService.insertTycCompany(tycCompany));
    }

    /**
     * 修改天眼查网站上-公司信息
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        TycCompany tycCompany = tycCompanyService.selectTycCompanyById(id);
        mmap.put("tycCompany", tycCompany);
        return prefix + "/edit";
    }

    /**
     * 修改保存天眼查网站上-公司信息
     */
    @RequiresPermissions("datacategory:company:edit")
    @Log(title = "天眼查网站上-公司信息", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(TycCompany tycCompany)
    {
        return toAjax(tycCompanyService.updateTycCompany(tycCompany));
    }

    /**
     * 删除天眼查网站上-公司信息
     */
    @RequiresPermissions("datacategory:company:remove")
    @Log(title = "天眼查网站上-公司信息", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(tycCompanyService.deleteTycCompanyByIds(ids));
    }
}

package com.ruoyi.elasticsearch.datacategory.service;

import com.ruoyi.elasticsearch.datacategory.entity.EsCount;

import java.util.List;

/**
 * 各网站在ES中的数据量Service接口
 * 
 * @author Stephen
 * @date 2019-11-04
 */
public interface IEsCountService 
{
    /**
     * 查询各网站在ES中的数据量
     * 
     * @param id 各网站在ES中的数据量ID
     * @return 各网站在ES中的数据量
     */
    public EsCount selectEsCountById(Long id);

    /**
     * 查询各网站在ES中的数据量列表
     * 
     * @param esCount 各网站在ES中的数据量
     * @return 各网站在ES中的数据量集合
     */
    public List<EsCount> selectEsCountList(EsCount esCount);

    /**
     * 新增各网站在ES中的数据量
     * 
     * @param esCount 各网站在ES中的数据量
     * @return 结果
     */
    public int insertEsCount(EsCount esCount);

    /**
     * 修改各网站在ES中的数据量
     * 
     * @param esCount 各网站在ES中的数据量
     * @return 结果
     */
    public int updateEsCount(EsCount esCount);

    /**
     * 批量删除各网站在ES中的数据量
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteEsCountByIds(String ids);

    /**
     * 删除各网站在ES中的数据量信息
     * 
     * @param id 各网站在ES中的数据量ID
     * @return 结果
     */
    public int deleteEsCountById(Long id);
}

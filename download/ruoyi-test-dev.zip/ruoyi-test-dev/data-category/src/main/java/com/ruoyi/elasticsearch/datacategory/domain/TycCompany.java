package com.ruoyi.elasticsearch.datacategory.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;
import java.util.Date;

/**
 * 天眼查网站上-公司信息对象 tyc_company
 * 
 * @author Stephen
 * @date 2019-11-21
 */
public class TycCompany extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** ID */
    private Long id;

    /** 公司名称 */
    @Excel(name = "公司名称")
    private String companyName;

    /** 法定代表人 */
    @Excel(name = "法定代表人")
    private String legalRepresentative;

    /** 注册资本(可能没有该信息) */
    @Excel(name = "注册资本(可能没有该信息)")
    private String registeredCapital;

    /** 成立日期(可能没有该信息) */
    @Excel(name = "成立日期(可能没有该信息)", width = 30, dateFormat = "yyyy-MM-dd")
    private Date dateEstablishment;

    /** 经营状态 */
    @Excel(name = "经营状态")
    private String businessStatus;

    /** 所属省份 */
    @Excel(name = "所属省份")
    private String province;

    /** 所属市区 */
    @Excel(name = "所属市区")
    private String urbanArea;

    /** 所属区县 */
    @Excel(name = "所属区县")
    private String district;

    /** 公司类型 */
    @Excel(name = "公司类型")
    private String typeCompany;

    /** 统一社会信用代码 */
    @Excel(name = "统一社会信用代码")
    private String unifiedSocialCreditCode;

    /** 企业公示的联系电话 */
    @Excel(name = "企业公示的联系电话")
    private String contactNumber;

    /** 企业公示的联系电话（更多号码） */
    @Excel(name = "企业公示的联系电话", readConverterExp = "更=多号码")
    private String moreContactNumber;

    /** 企业公示的地址 */
    @Excel(name = "企业公示的地址")
    private String address;

    /** 企业公示的网址 */
    @Excel(name = "企业公示的网址")
    private String internetSite;

    /** 企业公示的邮箱 */
    @Excel(name = "企业公示的邮箱")
    private String email;

    /** 经营范围 */
    @Excel(name = "经营范围")
    private String businessScope;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setCompanyName(String companyName) 
    {
        this.companyName = companyName;
    }

    public String getCompanyName() 
    {
        return companyName;
    }
    public void setLegalRepresentative(String legalRepresentative) 
    {
        this.legalRepresentative = legalRepresentative;
    }

    public String getLegalRepresentative() 
    {
        return legalRepresentative;
    }
    public void setRegisteredCapital(String registeredCapital) 
    {
        this.registeredCapital = registeredCapital;
    }

    public String getRegisteredCapital() 
    {
        return registeredCapital;
    }
    public void setDateEstablishment(Date dateEstablishment) 
    {
        this.dateEstablishment = dateEstablishment;
    }

    public Date getDateEstablishment() 
    {
        return dateEstablishment;
    }
    public void setBusinessStatus(String businessStatus) 
    {
        this.businessStatus = businessStatus;
    }

    public String getBusinessStatus() 
    {
        return businessStatus;
    }
    public void setProvince(String province) 
    {
        this.province = province;
    }

    public String getProvince() 
    {
        return province;
    }
    public void setUrbanArea(String urbanArea) 
    {
        this.urbanArea = urbanArea;
    }

    public String getUrbanArea() 
    {
        return urbanArea;
    }
    public void setDistrict(String district) 
    {
        this.district = district;
    }

    public String getDistrict() 
    {
        return district;
    }
    public void setTypeCompany(String typeCompany) 
    {
        this.typeCompany = typeCompany;
    }

    public String getTypeCompany() 
    {
        return typeCompany;
    }
    public void setUnifiedSocialCreditCode(String unifiedSocialCreditCode) 
    {
        this.unifiedSocialCreditCode = unifiedSocialCreditCode;
    }

    public String getUnifiedSocialCreditCode() 
    {
        return unifiedSocialCreditCode;
    }
    public void setContactNumber(String contactNumber) 
    {
        this.contactNumber = contactNumber;
    }

    public String getContactNumber() 
    {
        return contactNumber;
    }
    public void setMoreContactNumber(String moreContactNumber) 
    {
        this.moreContactNumber = moreContactNumber;
    }

    public String getMoreContactNumber() 
    {
        return moreContactNumber;
    }
    public void setAddress(String address) 
    {
        this.address = address;
    }

    public String getAddress() 
    {
        return address;
    }
    public void setInternetSite(String internetSite) 
    {
        this.internetSite = internetSite;
    }

    public String getInternetSite() 
    {
        return internetSite;
    }
    public void setEmail(String email) 
    {
        this.email = email;
    }

    public String getEmail() 
    {
        return email;
    }
    public void setBusinessScope(String businessScope) 
    {
        this.businessScope = businessScope;
    }

    public String getBusinessScope() 
    {
        return businessScope;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("companyName", getCompanyName())
            .append("legalRepresentative", getLegalRepresentative())
            .append("registeredCapital", getRegisteredCapital())
            .append("dateEstablishment", getDateEstablishment())
            .append("businessStatus", getBusinessStatus())
            .append("province", getProvince())
            .append("urbanArea", getUrbanArea())
            .append("district", getDistrict())
            .append("typeCompany", getTypeCompany())
            .append("unifiedSocialCreditCode", getUnifiedSocialCreditCode())
            .append("contactNumber", getContactNumber())
            .append("moreContactNumber", getMoreContactNumber())
            .append("address", getAddress())
            .append("internetSite", getInternetSite())
            .append("email", getEmail())
            .append("businessScope", getBusinessScope())
            .toString();
    }
}

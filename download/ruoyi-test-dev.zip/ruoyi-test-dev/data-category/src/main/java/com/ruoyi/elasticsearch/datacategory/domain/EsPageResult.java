package com.ruoyi.elasticsearch.datacategory.domain;

import java.util.List;

/**
 * @author Stephen
 * @description
 * @date 2019/11/6
 */
public class EsPageResult<T> {
    long total;
    int totalPages;
    List<T> resultList;

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public List<T> getResultList() {
        return resultList;
    }

    public void setResultList(List<T> resultList) {
        this.resultList = resultList;
    }
}

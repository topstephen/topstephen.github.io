package com.ruoyi.elasticsearch.datacategory.service.impl;

import cn.wanghaomiao.xpath.exception.XpathSyntaxErrorException;
import cn.wanghaomiao.xpath.model.JXDocument;
import com.alibaba.fastjson.JSON;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.security.Md5Utils;
import com.ruoyi.elasticsearch.datacategory.dao.EsBeanRepository;
import com.ruoyi.elasticsearch.datacategory.dao.SuduCategoryRepository;
import com.ruoyi.elasticsearch.datacategory.domain.TycCompany;
import com.ruoyi.elasticsearch.datacategory.entity.*;
import com.ruoyi.elasticsearch.datacategory.mapper.EsCountMapper;
import com.ruoyi.elasticsearch.datacategory.mapper.EsWebMsgMapper;
import com.ruoyi.elasticsearch.datacategory.mapper.TycCompanyMapper;
import com.ruoyi.elasticsearch.datacategory.service.EsService;
import com.ruoyi.elasticsearch.datacategory.service.IEsLogService;
import org.elasticsearch.index.query.QueryBuilders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author Stephen
 * @description
 * @date 2019/10/30
 */
@Service
public class EsServiceImpl implements EsService {


    private static final Logger log = LoggerFactory.getLogger(EsServiceImpl.class);

    @Autowired
    private EsBeanRepository esBeanRepository;
    @Autowired
    private SuduCategoryRepository suduCategoryRepository;

    @Autowired
    private IEsLogService iEsLogService;

    @Autowired
    private EsWebMsgMapper esWebMsgMapper;

    @Autowired
    private EsCountMapper esCountMapper;

    @Autowired
    private TycCompanyMapper tycCompanyMapper;

    /**
     * @param webMsgEntity 网站信息的实体类
     * @description 将整个网站的信息 解析并保存到 Es
     */
    @Override
    public void saveAndAnalysisWebData(WebMsgEntity webMsgEntity) {

        int pageSize = 100;
        long success = 0;
        long fail = 0;
        // "http://www.gcfd.cn"
        // 丰都新闻网ch
        // //div[@id='fontzoom']//text()
        String webUrl = webMsgEntity.getWebUrl();
        String webName = webMsgEntity.getWebName();
        String xpath = webMsgEntity.getXpath();
        String category = webMsgEntity.getCategory();
        Page<SuduEntity> page = this.getDataFromEsByUrlAndPageParm(0, pageSize, webUrl);
        int totalPages = page.getTotalPages();
        long totalElements = page.getTotalElements();
        // TODO 获取到的内容为空
        Map<String, Object> map = this.saveToEs(page.getContent(), xpath, webName, category);
        success += (long) map.get("success");
        fail += (long) map.get("fail");
        String exampleContent = (String) map.get("exampleContent");
        for (int i = 1; i < totalPages; i++) {
            page = this.getDataFromEsByUrlAndPageParm(i, pageSize, webUrl);
            Map<String, Object> mapTwo = this.saveToEs(page.getContent(), xpath, webName, category);
            success += (long) mapTwo.get("success");
            fail += (long) mapTwo.get("fail");
        }
        // 记录日志   XX网站  xpath  时间    成功数量  失败数量
        this.saveEsLog(fail, success, totalElements, exampleContent, webName, xpath);
    }

    /**
     * @return
     * @description 统计各网站在ES中的数据量
     */
    @Override
    public long countAll() {
        // 各个网站数据量和
        long count = 0;
        List<EsWebMsg> esWebMsgList = esWebMsgMapper.selectEsWebMsgList(new EsWebMsg());
        HashMap<Long, String> contentMap = new HashMap<>(256);
        for (EsWebMsg esWebMsg : esWebMsgList) {
            String content = "";
            String webUrl = esWebMsg.getUrl();
            String webName = esWebMsg.getWebName();
            String xpath = esWebMsg.getXpath();
            Long id = esWebMsg.getId();
            Page<SuduEntity> page = this.getDataFromEsByUrlAndPageParm(0, 1, webUrl);
            long totalElements = page.getTotalElements();
            List<SuduEntity> suduEntityList = page.getContent();
            if (Objects.nonNull(suduEntityList) && suduEntityList.size() > 0) {
                content = suduEntityList.get(0).getContent();
                // 解析html
                content = this.getContent(content, xpath);
                contentMap.put(id, content);
            }
            // 记录日志
            EsCount esCount = new EsCount();
            esCount.setEsUrl(webUrl);
            esCount.setEsWebName(webName);
            esCount.setEsXpath(xpath);
            esCount.setId(id);
            // 每个网站数据量
            esCount.setEsStandby1(totalElements + "");
            EsCount esCountQuery = esCountMapper.selectEsCountById(id);
            if (Objects.isNull(esCountQuery)) {
                esCountMapper.insertEsCount(esCount);
            } else {
                esCountMapper.updateEsCount(esCount);
            }
            count += totalElements;
        }

        List<EsCount> esCounts = esCountMapper.selectEsCountList(new EsCount());
        for (EsCount esCount : esCounts) {
            Map<String, String> contentAndTotalCount = new HashMap<>();
            String content = contentMap.get(esCount.getId());
            contentAndTotalCount.put("content", content);
            System.out.println(content);
            contentAndTotalCount.put("totalCount", count + "");
            String json = JSON.toJSONString(contentAndTotalCount);
            esCount.setEsStandby2(json);
            esCountMapper.updateEsCount(esCount);
        }
        return count;
    }

    /**
     * @param province 省份
     * @return void
     * @description 保存 天眼查网站上 公司信息到ES
     */
    @Override
    public void saveTycCompanyToEs(String province) {
        TycCompany queryTycCompany = new TycCompany();
        queryTycCompany.setProvince(province);
        List<TycCompany> tycCompanyList = tycCompanyMapper.selectTycCompanyList(queryTycCompany);
        List<SuduCategoryEntity> suduCategoryEntityList = new ArrayList<>(6000);
        for (TycCompany tycCompany : tycCompanyList) {
            SuduCategoryEntity suduCategoryEntity = new SuduCategoryEntity();

            String companyName = tycCompany.getCompanyName();
            String internetSite = tycCompany.getInternetSite();
            if (StringUtils.isNotEmpty(internetSite)) {
                tycCompany.setInternetSite(internetSite.replaceAll("\t", ""));
            }
            String email = tycCompany.getEmail();
            if (StringUtils.isNotEmpty(email)) {
                tycCompany.setEmail(email.replaceAll("\t", ""));

            }
            String content = JSON.toJSONString(tycCompany);
            suduCategoryEntity.setId(Md5Utils.hash(companyName));
            suduCategoryEntity.setContent(content);
            suduCategoryEntity.setArea(province);
            suduCategoryEntity.setComment("null");
            suduCategoryEntity.setCategory("G");
            suduCategoryEntity.setTitle(companyName);
            suduCategoryEntity.setType("综合资讯");
            suduCategoryEntity.setUrl("https://www.tianyancha.com");
            suduCategoryEntity.setWebName("天眼查");
            suduCategoryEntity.setCrawlingTime(new Date());
            suduCategoryEntity.setPubTime(new Date());
            suduCategoryEntity.setSaveTime(new Date());
            suduCategoryEntityList.add(suduCategoryEntity);
        }
        suduCategoryRepository.saveAll(suduCategoryEntityList);
    }

    @Override
    public void saveTycCompanyToEsAll() {
        TycCompany queryTycCompany = new TycCompany();
        List<TycCompany> tycCompanyList = tycCompanyMapper.selectTycCompanyList(queryTycCompany);
        List<SuduCategoryEntity> suduCategoryEntityList = new LinkedList<>();
        for (TycCompany tycCompany : tycCompanyList) {
            SuduCategoryEntity suduCategoryEntity = new SuduCategoryEntity();
            String companyName = tycCompany.getCompanyName();
            String internetSite = tycCompany.getInternetSite();

            if (StringUtils.isNotEmpty(internetSite)) {
                tycCompany.setInternetSite(internetSite.replaceAll("\t", ""));
            }
            String email = tycCompany.getEmail();
            if (StringUtils.isNotEmpty(email)) {
                tycCompany.setEmail(email.replaceAll("\t", ""));

            }
            String content = JSON.toJSONString(tycCompany);
            suduCategoryEntity.setId(Md5Utils.hash(companyName));
            suduCategoryEntity.setContent(content);
            suduCategoryEntity.setArea(tycCompany.getProvince());
            suduCategoryEntity.setComment("null");
            suduCategoryEntity.setCategory("G");
            suduCategoryEntity.setTitle(companyName);
            suduCategoryEntity.setType("综合资讯");
            suduCategoryEntity.setUrl("https://www.tianyancha.com");
            suduCategoryEntity.setWebName("天眼查");
            suduCategoryEntity.setCrawlingTime(new Date());
            suduCategoryEntity.setPubTime(new Date());
            suduCategoryEntity.setSaveTime(new Date());
            suduCategoryEntityList.add(suduCategoryEntity);
        }
        suduCategoryRepository.saveAll(suduCategoryEntityList);
    }


    private void saveEsLog(long fail, long success, long total, String exampleContent, String webName, String xpath) {
        EsLog esLog = new EsLog();
        esLog.setEsCreate(new Date());
        esLog.setEsModified(new Date());
        esLog.setEsFail(fail);
        esLog.setEsSuccess(success);
        esLog.setEsTotal(total);
        esLog.setEsExamplecontent(exampleContent);
        esLog.setEsWebname(webName);
        esLog.setEsXpath(xpath);
        iEsLogService.insertEsLog(esLog);
    }


    /**
     * @param suduEntityList
     * @param xpath
     * @param webName
     * @description 保存一页数据到ES
     */
    private Map<String, Object> saveToEs(List<SuduEntity> suduEntityList, String xpath, String webName, String category) {
        long success = 0;
        long fail = 0;
        List<SuduCategoryEntity> suduCategoryEntityList = new ArrayList<>(1000);
        for (SuduEntity suduEntity : suduEntityList) {

            String html = suduEntity.getContent();
            String content = this.getContent(html, xpath);
            SuduCategoryEntity categoryEntity = new SuduCategoryEntity();
            BeanUtils.copyProperties(suduEntity, categoryEntity, "content");
            categoryEntity.setSaveTime(new Date());
            categoryEntity.setContent(content);
            categoryEntity.setWebName(webName);
            // TODO 设置分类
            categoryEntity.setCategory(category);
            suduCategoryEntityList.add(categoryEntity);
        }
        int size = suduCategoryEntityList.size();
        try {
            // 批量保存
            suduCategoryRepository.saveAll(suduCategoryEntityList);
            success += size;

        } catch (Exception e) {
            e.printStackTrace();
            fail += size;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("success", success);
        map.put("fail", fail);
        map.put("exampleContent", suduCategoryEntityList.get(0).getContent());
        return map;
    }


    /**
     * @param page
     * @param size
     * @param webUrl 网站地址
     * @description 根据网站地址从Es中获取数据
     */
    public Page<SuduEntity> getDataFromEsByUrlAndPageParm(int page, int size, String webUrl) {
        NativeSearchQueryBuilder queryBuilder = new NativeSearchQueryBuilder();
        //添加查询条件
        queryBuilder.withQuery(QueryBuilders.wildcardQuery("url", "*" + webUrl + "*"));
        //分页
        queryBuilder.withPageable(PageRequest.of(page, size));
        Page<SuduEntity> result = esBeanRepository.search(queryBuilder.build());
        return result;
    }

    /**
     * @param html
     * @param xpath
     * @return java.lang.String
     * @description 解析html内容 提取新闻信息
     */
    public String getContent(String html, String xpath) {
        if (StringUtils.contains(xpath, "\"")) {
            xpath = StringUtils.replace(xpath, "\"", "\'");

        }
        JXDocument jxDocument = new JXDocument(html);
        List<Object> rs = null;
        try {
            rs = jxDocument.sel(xpath);
        } catch (XpathSyntaxErrorException e) {
            log.error("该xpath存在问题【{}】", xpath);
            e.printStackTrace();
        }
        String context = "";
        if (Objects.nonNull(rs) && rs.size() > 0) {
            context = rs.get(0).toString();
        }
        return context;
    }


}

package com.ruoyi.elasticsearch.datacategory.entity;

/**
 * @author Stephen
 * @description
 * @date 2019/10/31
 */
public class WebMsgEntity {

    private String xpath;
    private String webName;
    private String webUrl;
    private String category;

    public WebMsgEntity() {
    }

    public WebMsgEntity(String xpath, String webName, String webUrl, String category) {
        this.xpath = xpath;
        this.webName = webName;
        this.webUrl = webUrl;
        this.category = category;
    }

    public String getXpath() {
        return xpath;
    }

    public void setXpath(String xpath) {
        this.xpath = xpath;
    }

    public String getWebName() {
        return webName;
    }

    public void setWebName(String webName) {
        this.webName = webName;
    }

    public String getWebUrl() {
        return webUrl;
    }

    public void setWebUrl(String webUrl) {
        this.webUrl = webUrl;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}

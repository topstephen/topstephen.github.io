package com.ruoyi.elasticsearch.datacategory.service.impl;


import com.ruoyi.common.core.text.Convert;
import com.ruoyi.elasticsearch.datacategory.entity.EsLog;
import com.ruoyi.elasticsearch.datacategory.mapper.EsLogMapper;
import com.ruoyi.elasticsearch.datacategory.service.IEsLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 数据分类转存ES日志Service业务层处理
 * 
 * @author Stephen
 * @date 2019-11-03
 */
@Service
public class EsLogServiceImpl implements IEsLogService
{
    @Autowired
    private EsLogMapper esLogMapper;

    /**
     * 查询数据分类转存ES日志
     * 
     * @param id 数据分类转存ES日志ID
     * @return 数据分类转存ES日志
     */
    @Override
    public EsLog selectEsLogById(Long id)
    {
        return esLogMapper.selectEsLogById(id);
    }

    /**
     * 查询数据分类转存ES日志列表
     * 
     * @param esLog 数据分类转存ES日志
     * @return 数据分类转存ES日志
     */
    @Override
    public List<EsLog> selectEsLogList(EsLog esLog)
    {
        return esLogMapper.selectEsLogList(esLog);
    }

    /**
     * 新增数据分类转存ES日志
     * 
     * @param esLog 数据分类转存ES日志
     * @return 结果
     */
    @Override
    public int insertEsLog(EsLog esLog)
    {
        return esLogMapper.insertEsLog(esLog);
    }

    /**
     * 修改数据分类转存ES日志
     * 
     * @param esLog 数据分类转存ES日志
     * @return 结果
     */
    @Override
    public int updateEsLog(EsLog esLog)
    {
        return esLogMapper.updateEsLog(esLog);
    }

    /**
     * 删除数据分类转存ES日志对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteEsLogByIds(String ids)
    {
        return esLogMapper.deleteEsLogByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除数据分类转存ES日志信息
     * 
     * @param id 数据分类转存ES日志ID
     * @return 结果
     */
    @Override
    public int deleteEsLogById(Long id)
    {
        return esLogMapper.deleteEsLogById(id);
    }
}

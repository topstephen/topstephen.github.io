package com.ruoyi.elasticsearch.datacategory.dao;

import com.ruoyi.elasticsearch.datacategory.entity.PlatformEntity;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface PlatformRepository extends ElasticsearchRepository<PlatformEntity, String> {
}

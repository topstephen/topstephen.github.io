package com.ruoyi.elasticsearch.datacategory.service;

import com.ruoyi.elasticsearch.datacategory.domain.EsPageResult;
import com.ruoyi.elasticsearch.datacategory.domain.QueryPageRequest;
import com.ruoyi.elasticsearch.datacategory.entity.SuduCategoryEntity;

import java.util.Map;

/**
 * @author Stephen
 * @description
 * @date 2019/11/6
 */

public interface EsQueryService {
    public EsPageResult<SuduCategoryEntity> findByCondition(QueryPageRequest queryPageRequest, int page, int size);

    public Map<String, Long> findCategoryCount();
}

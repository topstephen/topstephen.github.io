package com.ruoyi.elasticsearch.datacategory.dao;

import com.ruoyi.elasticsearch.datacategory.entity.SuduEntity;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface EsBeanRepository extends ElasticsearchRepository<SuduEntity, String> {
}

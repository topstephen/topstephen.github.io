#!/bin/sh

#  install_kcptun.sh
#  ShadowsocksX

#VERSION="20171113"
VERSION="20180316"

cd `dirname "${BASH_SOURCE[0]}"`
INSTALL_DIR="$HOME/Library/Application Support/ShadowsocksX-App"
sudo mkdir -p "$INSTALL_DIR/kcptun_$VERSION"

cp -f kcptun_client "$INSTALL_DIR//kcptun_$VERSION/"
sudo rm -f "$INSTALL_DIR/kcptun_client"
sudo rm -fr "$INSTALL_DIR/kcptun_20171113"
ln -s "$INSTALL_DIR/kcptun_$VERSION/kcptun_client" "$INSTALL_DIR/kcptun_client"

echo "install kcptun client done"
